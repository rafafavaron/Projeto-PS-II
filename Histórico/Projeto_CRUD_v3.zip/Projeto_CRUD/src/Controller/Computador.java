/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author 31932835
 */
public class Computador {
    private int id;
    private String marca;
    private String processador;
    private int qtd_ram;
    private int tam_disco;
    
        public Computador(int id, String marca, String processador, int qtd_ram, int tam_disco){
        this.id = id;
        this.marca = marca;
        this.processador = processador;
        this.qtd_ram = qtd_ram;
        this.tam_disco = tam_disco;
    }
    
}
