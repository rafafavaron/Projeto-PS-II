/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author 31932835
 */
public class Produto {
    
    private int id;
    private String descricao;
    private String marca;
    private float preco;
   
        public Produto(int id, String descricao, String marca, float preco){
        this.id = id;
        this.descricao = descricao;
        this.marca = marca;
        this.preco = preco;
    }
    
}
