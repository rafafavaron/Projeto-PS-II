/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static java.lang.System.out;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 31932835
 */
public class BancoDAO {
    
    private PreparedStatement stmt;
    
    public BancoDAO(){
        try{
            String url = "jdbc:derby://localhost:1527/projeto_prog";
            String usuario = "aluno";
            String senha = "aluno";
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            out.println("Drive JDBC carregado!");
            java.sql.Connection conexao = DriverManager.getConnection(url,usuario, senha);
            out.println("Conexão Estabelecida com sucesso");
            
            this.stmt = conexao.prepareStatement("SELECT * FROM bancos");
       } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
                out.println("Driver não encontrado");
            } catch (SQLException ex){
                ex.printStackTrace();
                out.println("Erro de conexão");
            }
    }
    public List<Banco> lerTodos(){
        try{
            ResultSet rs = this.stmt.executeQuery();
            List<Banco> bancos = new ArrayList<>();
            while(rs.next()){
                Banco aux  = new Banco();
                aux.setId(rs.getInt("id"));
                aux.setNome(rs.getString("nome"));
                aux.setCnpj(rs.getString("cnpj"));
                aux.setNumeroCliente(rs.getInt("numero_cliente"));
                bancos.add(aux);   
            }
            return bancos;
        } catch(Exception ex) {
                ex.printStackTrace();
        }
        return null;
    }
    
}
