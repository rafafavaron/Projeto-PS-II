/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author 31932835
 */
public class Banco {
    private int id;
    private String nome;
    private String cnpj;
    private int numeroCliente;
    
    public Banco(){}
    
    public Banco(int id, String nome, String cnpj, int numeroCliente){
        this.id = id;
        this.nome = nome;
        this.cnpj = cnpj;
        this.numeroCliente = numeroCliente;
    }
    
    public String getNome(){
        return nome;
    }

    void setId(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setNome(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setCnpj(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setNumeroCliente(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
